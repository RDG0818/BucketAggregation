// include/queues/two_level_bucket_queue.h

#pragma once

#include <limits>
#include <memory>
#include <vector>
#include <numeric>
#include <cmath>

#include "environments/node.h"
#include "utils/utils.h"

struct Block {
  static constexpr size_t SIZE = 126; // total size: 126 x 4 + 8 = 512 bytes
  uint32_t elements[SIZE];
  Block* next = nullptr;
};

// NOTE: I didn't realize you were using a block pool in this way. Have you tried just using a vector for
// the secondary buckets and letting them handle the memory management for you? I only ask because that's
// what I did, and I'd be curious if you tried that and then switched to this for a particular reason.
// Thinking about it, I would expect that this strategy actually serves you better in the grid domain by
// reducing the total number of allocations performed on the sparsely populated secondary buckets. But I
// also suspect that this approach may *increase* the total number of allocations performed in domains
// with sufficiently large state spaces that have more densely populated secondary buckets. Thoughts
// on this?
class BlockPool {

public:

  BlockPool(size_t chunk_size = 1000, size_t initial_capacity = 0) 
  : chunk_size_(chunk_size) {
    if (initial_capacity > 0) {
      reserve(initial_capacity);
    }
  };
  // NOTE: Since you're just defaulting this, it's better to omit it entirely.
  //~BlockPool() = default;

  Block* allocate() {
    if (!free_list_) {
      allocate_chunk();
    }
    Block* block = free_list_;
    free_list_ = free_list_->next;
    block->next = nullptr;
    return block;
  }

  // NOTE: Mark noexcept
  void deallocate(Block* block) noexcept {
    block->next = free_list_;
    free_list_ = block;
  }

  void reserve(size_t n_blocks) {
    while (capacity_ < n_blocks) {
      allocate_chunk();
    }
  }

  void clear() {
    free_list_ = nullptr;
    capacity_ = 0;
    chunks_.clear();
  }

private:

  void allocate_chunk() {
    auto chunk = std::make_unique<Block[]>(chunk_size_);

    for (size_t i = 0; i < chunk_size_ - 1; i++) {
      chunk[i].next = &chunk[i + 1];
    }
    chunk[chunk_size_ - 1].next = free_list_;
    free_list_ = &chunk[0];

    chunks_.push_back(std::move(chunk));
    capacity_ += chunk_size_;
  }

  size_t chunk_size_;
  size_t capacity_ = 0;
  Block* free_list_ = nullptr;
  std::vector<std::unique_ptr<Block[]>> chunks_;

};

// NOTE: Most of my comments here are about marking functions as noexcept. This is a promise to the compiler
// that the function will never throw an exception, which allows the compiler to optimize the function more
// aggressively and not include any exception handling. It's good practice to mark functions that can't throw
// as noexcept. It's possible that this could improve performance some, though it's not guaranteed
class TwoLevelBucketQueue {

private:

  struct SecondaryBucket {
    Block* head = nullptr;
    uint32_t top = 0;

    bool empty() const {return head == nullptr; };
  };

  struct PrimaryBucket {
    std::vector<SecondaryBucket> h_buckets;
    uint32_t h_min = INF_COST;
    size_t count = 0;
  };

public:

  TwoLevelBucketQueue(uint32_t f_cap_hint = 1024) 
  : f_offset_(0), f_min_idx_(INF_COST), count_(0), pool_(1000, 1000) {
    f_buckets_.reserve(f_cap_hint);
  }

  void push(uint32_t id, uint32_t f, uint32_t h) {
    if (count_ == 0) {
      f_offset_ = f;
      f_min_idx_ = 0;
    }

    if (f < f_offset_) {
      uint32_t delta = f_offset_ - f;
      f_buckets_.insert(f_buckets_.begin(), delta, PrimaryBucket{});
      f_offset_ = f;
      f_min_idx_ = 0;
    }

    uint32_t f_idx = f - f_offset_;
    if (f_idx >= f_buckets_.size()) {
      size_t new_size = std::max<size_t>(f_idx + 1, f_buckets_.size() * 1.5);
      f_buckets_.resize(new_size);
    }

    auto& p_bucket = f_buckets_[f_idx];

    if (h >= p_bucket.h_buckets.size()) {
      size_t new_size = std::max<size_t>(h + 1, p_bucket.h_buckets.size() * 1.5);
      p_bucket.h_buckets.resize(new_size);
    }

    auto& s_bucket = p_bucket.h_buckets[h];

    if (!s_bucket.head || s_bucket.top == Block::SIZE) {
      Block* new_block = pool_.allocate();
      new_block->next = s_bucket.head;
      s_bucket.head = new_block;
      s_bucket.top = 0;
    }

    s_bucket.head->elements[s_bucket.top++] = id;

    p_bucket.count++;
    count_++;

    if (h < p_bucket.h_min) p_bucket.h_min = h;
    if (f_idx < f_min_idx_) f_min_idx_ = f_idx;
  }

  // NOTE: This won't perform any allocation, so it should be non-throwing. Mark noexcept to have compiler leave out exception handling
  // for this function. All functions it calls should be marked noexcept as well.
  uint32_t pop() noexcept {
    if (count_ == 0) return INF_COST;

    // NOTE: Branch predictors are mythical beasts, so I can't say for sure what I'm about to say will be of any use at all, but
    // I believe that ordinarily for loops it's assumed that the branch will be taken. This is because you normally loop for a while
    // and only stop at the end, so you'd only have a single missed branch prediction that way. BUT for this case, we assume that the vast
    // majority of the time this loop should break without ever performing work. So, it's possible that we're all but guaranteeing a
    // branch misprediction here. So, it's *possible* - though unlikely - that wrapping this loop in an if statement could somewhat
    // improve the performance of this function by reducing the number of mispredicted branches. But, maybe the branch predictor is
    // already smart enough to be updating its behavior for this loop anyway, in which case there wouldn't be a change in performance.
    while (f_min_idx_ < f_buckets_.size() && f_buckets_[f_min_idx_].count == 0) {
      f_min_idx_++;
    }

    if (f_min_idx_ >= f_buckets_.size()) {
      count_ = 0;
      return INF_COST;
    }

    return pop_from_bucket(f_buckets_[f_min_idx_]);
  }

  // NOTE: noexcept
  uint32_t pop_from(uint32_t f) noexcept {
    if (f < f_offset_) return NODE_NULL;
    uint32_t f_idx = f - f_offset_;
    if (f_idx >= f_buckets_.size() || f_buckets_[f_idx].count == 0) {
      return NODE_NULL;
    }

    return pop_from_bucket(f_buckets_[f_idx]);
  }

  // NOTE: noexcept
  size_t get_node_count(uint32_t f) const noexcept {
    if (f < f_offset_) return 0;
    uint32_t f_idx = f - f_offset_;
    if (f_idx >= f_buckets_.size()) return 0;
    return f_buckets_[f_idx].count;
  }

  // NOTE: noexcept
  uint32_t get_h_min(uint32_t f) const noexcept {
    if (f < f_offset_) return INF_COST;
    uint32_t f_idx = f - f_offset_;
    if (f_idx >= f_buckets_.size()) return INF_COST;
    return f_buckets_[f_idx].h_min;
  }

  // NOTE: noexcept
  uint32_t peek_top_node(uint32_t f, uint32_t h) const noexcept {
    if (f < f_offset_) return NODE_NULL;
    uint32_t f_idx = f - f_offset_;
    if (f_idx >= f_buckets_.size() || h >= f_buckets_[f_idx].h_buckets.size()) {  
      return NODE_NULL;
    }

    const auto& s_bucket = f_buckets_[f_idx].h_buckets[h];
    if (s_bucket.empty()) return NODE_NULL;

    return s_bucket.head->elements[s_bucket.top - 1];
  }

  // NOTE: noexcept
  void set_f_min(uint32_t f) noexcept {
    if (f < f_offset_) f_min_idx_ = 0;
    else f_min_idx_ = f - f_offset_;
  }

  // NOTE: noexcept
  uint32_t get_f_min() const noexcept {
    while (f_min_idx_ < f_buckets_.size() && f_buckets_[f_min_idx_].count == 0) {
      f_min_idx_++;
    }
    if (f_min_idx_ >= f_buckets_.size()) return f_offset_ + f_buckets_.size();
    return f_offset_ + f_min_idx_;
  }

  // NOTE: noexcept
  uint32_t get_alpha() const noexcept { return 1; }
  uint32_t get_beta() const noexcept { return 1; }

  // NOTE: noexcept
  bool empty() const noexcept { return count_ == 0; };

  // NOTE: noexcept
  void clear() noexcept {
    f_buckets_.clear();
    f_offset_ = 0;
    f_min_idx_ = INF_COST;
    count_ = 0;
    pool_.clear();
  }

  template <typename Validator>
  utils::QueueDetailedMetrics get_detailed_metrics(Validator&& is_stale) const {
    utils::QueueDetailedMetrics m;
    m.primary_buckets_total = f_buckets_.size();
    m.f_min = get_f_min();
    m.f_max = f_offset_ + f_buckets_.size() - 1;

    std::vector<uint32_t> h_mins;
    std::vector<uint32_t> h_maxs;
    std::vector<double> sec_per_pri_vals;
    std::vector<size_t> nodes_per_sec_vals;

    for (uint32_t f_idx = 0; f_idx < f_buckets_.size(); ++f_idx) {
      const auto& p_bucket = f_buckets_[f_idx];
      uint32_t f_val = f_offset_ + f_idx;
      if (p_bucket.count == 0) continue;

      m.primary_buckets_nonempty++;
      m.f_max = f_val;
      m.secondary_buckets_total += p_bucket.h_buckets.size();

      uint32_t local_h_min = INF_COST;
      uint32_t local_h_max = 0;
      size_t local_sec_nonempty = 0;
      bool p_bucket_has_logical = false;

      for (uint32_t h = 0; h < p_bucket.h_buckets.size(); ++h) {
        const auto& s_bucket = p_bucket.h_buckets[h];
        if (s_bucket.empty()) continue;

        local_sec_nonempty++;
        m.secondary_buckets_nonempty++;
        if (h < local_h_min) local_h_min = h;
        if (h > local_h_max) local_h_max = h;

        size_t node_count = 0;
        size_t logical_node_count = 0;
        Block* curr = s_bucket.head;
        uint32_t top = s_bucket.top;
        while (curr) {
          for (uint32_t i = 0; i < top; ++i) {
            if (!is_stale(curr->elements[i], f_val, h)) {
              logical_node_count++;
            }
          }
          node_count += top;
          curr = curr->next;
          top = Block::SIZE;
        }

        if (logical_node_count > 0) {
          m.logical_secondary_nonempty++;
          m.logical_nodes_total += logical_node_count;
          p_bucket_has_logical = true;
        }

        m.h_distribution[h] += node_count;
        nodes_per_sec_vals.push_back(node_count);
      }

      if (p_bucket_has_logical) {
        m.logical_primary_nonempty++;
      }

      if (local_h_min != INF_COST) {
        h_mins.push_back(local_h_min);
        h_maxs.push_back(local_h_max);
        sec_per_pri_vals.push_back(static_cast<double>(local_sec_nonempty));
      }
    }

    auto calculate_stats = [](const auto& v, double& mean, double& stddev) {
      if (v.empty()) {
        mean = 0; stddev = 0;
        return;
      }
      double sum = std::accumulate(v.begin(), v.end(), 0.0);
      mean = sum / v.size();
      double sq_sum = std::inner_product(v.begin(), v.end(), v.begin(), 0.0);
      stddev = std::sqrt(std::max(0.0, sq_sum / v.size() - mean * mean));
    };

    calculate_stats(h_mins, m.h_min_mean, m.h_min_stddev);
    calculate_stats(h_maxs, m.h_max_mean, m.h_max_stddev);
    calculate_stats(sec_per_pri_vals, m.sec_per_pri_mean, m.sec_per_pri_stddev);
    calculate_stats(nodes_per_sec_vals, m.nodes_per_sec_mean, m.nodes_per_sec_stddev);

    return m;
  }

  utils::QueueDetailedMetrics get_detailed_metrics() const {
    auto is_stale_stub = [](uint32_t, uint32_t, uint32_t) { return false; };
    return get_detailed_metrics(is_stale_stub);
  }

  template <typename T> void rebuild(T) {}

private:

  // NOTE: Per previous comment, mark noexcept.
  uint32_t pop_from_bucket(PrimaryBucket& p_bucket) noexcept {
    while(p_bucket.h_min < p_bucket.h_buckets.size() &&
          p_bucket.h_buckets[p_bucket.h_min].empty()) {
      p_bucket.h_min++;
    }

    if (p_bucket.h_min >= p_bucket.h_buckets.size()) {
      return NODE_NULL;
    }

    auto& s_bucket = p_bucket.h_buckets[p_bucket.h_min];
    uint32_t id = s_bucket.head->elements[--s_bucket.top];

    if (s_bucket.top == 0) {
      Block* old_head = s_bucket.head;
      s_bucket.head = s_bucket.head->next;
      pool_.deallocate(old_head);
      
      if (s_bucket.head) s_bucket.top = Block::SIZE;
    }
    
    p_bucket.count--;
    count_--;

    if (p_bucket.count > 0 && s_bucket.empty()) {
      while (p_bucket.h_min < p_bucket.h_buckets.size() &&
             p_bucket.h_buckets[p_bucket.h_min].empty()) {
        p_bucket.h_min++;
      };
    }

    return id;
  }

  std::vector<PrimaryBucket> f_buckets_;
  uint32_t f_offset_;
  mutable uint32_t f_min_idx_;
  size_t count_;
  BlockPool pool_;
};
